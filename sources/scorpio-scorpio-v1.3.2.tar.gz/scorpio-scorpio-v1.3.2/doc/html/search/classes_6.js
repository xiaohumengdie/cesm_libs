var searchData=
[
  ['var_5fdesc_5ft',['var_desc_t',['../structvar__desc__t.html',1,'var_desc_t'],['../structpio__types_1_1var__desc__t.html',1,'pio_types::var_desc_t']]]
];
