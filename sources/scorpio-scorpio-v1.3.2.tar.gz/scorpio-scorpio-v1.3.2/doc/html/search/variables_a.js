var searchData=
[
  ['ndims',['ndims',['../structio__desc__t.html#a258b4083cf5f5afaf66abdbe3db01a89',1,'io_desc_t']]],
  ['ndof',['ndof',['../structio__desc__t.html#a66ce0ae69f67e84921bbf85508fd015f',1,'io_desc_t']]],
  ['needsfill',['needsfill',['../structio__desc__t.html#ae091e478cb04d7b108cb1e124c05355d',1,'io_desc_t']]],
  ['next',['next',['../structio__region.html#a15971dd265f37af41a802fea02eea4e9',1,'io_region::next()'],['../structio__desc__t.html#a270324af754251cf5b00971060288fbb',1,'io_desc_t::next()'],['../structiosystem__desc__t.html#ad4885665a95c1c45ce592e180e127e34',1,'iosystem_desc_t::next()'],['../structwmulti__buffer.html#ab923221c5ae847881aa90bbcf5d85730',1,'wmulti_buffer::next()'],['../structfile__desc__t.html#ad70891a793de258f58752ec5170ee80e',1,'file_desc_t::next()']]],
  ['niotasks',['niotasks',['../structpioexample_1_1pioexampleclass.html#aa1fa3c0e1f613c945576ea89b2dd08c3',1,'pioexample::pioexampleclass']]],
  ['nrecvs',['nrecvs',['../structio__desc__t.html#a5409346e91db139f59bd27d4ac91576c',1,'io_desc_t']]],
  ['nreqs',['nreqs',['../structvar__desc__t.html#a76c27fb609338d495267c9a77dc020bf',1,'var_desc_t']]],
  ['ntasks',['ntasks',['../structpioexample_1_1pioexampleclass.html#aed46d08dad41443efa0062661adb947d',1,'pioexample::pioexampleclass']]],
  ['num_5faiotasks',['num_aiotasks',['../structio__desc__t.html#a9ba719dc0fe06776d44e0d97f41b7148',1,'io_desc_t']]],
  ['num_5farrays',['num_arrays',['../structwmulti__buffer.html#af6cbf6c3857f980598096c6167e3fd0b',1,'wmulti_buffer']]],
  ['num_5fcomptasks',['num_comptasks',['../structiosystem__desc__t.html#accf4f177b28ebd9fb7c0e834aa241f75',1,'iosystem_desc_t']]],
  ['num_5fiotasks',['num_iotasks',['../structiosystem__desc__t.html#af28b0fb707990fbb0ac39001be15e616',1,'iosystem_desc_t']]],
  ['num_5fstypes',['num_stypes',['../structio__desc__t.html#a54cb4400ea3ac248cccb1b52a839686c',1,'io_desc_t']]],
  ['num_5funiontasks',['num_uniontasks',['../structiosystem__desc__t.html#a486d8239512cec3231f08973b34d3ac1',1,'iosystem_desc_t']]],
  ['numaggregator',['numaggregator',['../structpioexample_1_1pioexampleclass.html#ab5a1edadbb72cbdf6530dec85e431971',1,'pioexample::pioexampleclass']]]
];
