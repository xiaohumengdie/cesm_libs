var searchData=
[
  ['describing_20decompositions',['Describing decompositions',['../decomp.html',1,'']]]
];
