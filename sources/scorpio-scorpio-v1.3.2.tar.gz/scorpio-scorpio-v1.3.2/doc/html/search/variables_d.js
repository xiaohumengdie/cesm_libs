var searchData=
[
  ['rcount',['rcount',['../structio__desc__t.html#aff1ad34793e462c3807ebb3c1384dea9',1,'io_desc_t']]],
  ['readbuffer',['readbuffer',['../structpioexample_1_1pioexampleclass.html#a526361acbf70a77e0afe9d19498bba3b',1,'pioexample::pioexampleclass']]],
  ['rearr_5fopts',['rearr_opts',['../structio__desc__t.html#afe6b16e1e8f774639b0de1328f8981c9',1,'io_desc_t::rearr_opts()'],['../structiosystem__desc__t.html#a90c06b85112d2cbcef262b8a8c0aea12',1,'iosystem_desc_t::rearr_opts()']]],
  ['rearranger',['rearranger',['../structio__desc__t.html#a0b342635e05c4858cf057f28298f8213',1,'io_desc_t']]],
  ['record',['record',['../structvar__desc__t.html#a778c09b345537506feafa4f92705b6f5',1,'var_desc_t']]],
  ['recordvar',['recordvar',['../structwmulti__buffer.html#a52b790e294ce52e2b364f584abdbf9d8',1,'wmulti_buffer']]],
  ['request',['request',['../structvar__desc__t.html#afe58a0dd1a4e439098833e9dfa0e7102',1,'var_desc_t']]],
  ['request_5fsz',['request_sz',['../structvar__desc__t.html#a22a4d9b91a0926e90bece8c9db21d6f9',1,'var_desc_t']]],
  ['resultlen',['resultlen',['../example1_8c.html#aeb75303058f3be9b462de7ba3f6b03a7',1,'resultlen():&#160;example1.c'],['../example2_8c.html#aeb75303058f3be9b462de7ba3f6b03a7',1,'resultlen():&#160;example2.c'],['../put__var_8c.html#aeb75303058f3be9b462de7ba3f6b03a7',1,'resultlen():&#160;put_var.c']]],
  ['rfrom',['rfrom',['../structio__desc__t.html#aeb38b39c426eb0cce7c8e27d15eb67fd',1,'io_desc_t']]],
  ['rindex',['rindex',['../structio__desc__t.html#a1c5a340bb797121121f8c17203e5fb3c',1,'io_desc_t']]],
  ['rtype',['rtype',['../structio__desc__t.html#a2ebce2622d8c52bdaf07e00350acadce',1,'io_desc_t']]]
];
