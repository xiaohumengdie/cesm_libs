var searchData=
[
  ['error_20return_20codes',['error return codes',['../group__error__return.html',1,'']]],
  ['error_5fmethods',['error_methods',['../group___p_i_o__error__method.html',1,'']]]
];
