var searchData=
[
  ['start_5fdata_5fval',['START_DATA_VAL',['../example1_8c.html#aba5ba18a0b68130c63410845f87fa708',1,'START_DATA_VAL():&#160;example1.c'],['../example2_8c.html#aba5ba18a0b68130c63410845f87fa708',1,'START_DATA_VAL():&#160;example2.c']]]
];
