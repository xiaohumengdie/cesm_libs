var searchData=
[
  ['var_5fname',['VAR_NAME',['../example1_8c.html#a73de0b1772c59096554d6a846feff376',1,'VAR_NAME():&#160;example1.c'],['../example2_8c.html#a73de0b1772c59096554d6a846feff376',1,'VAR_NAME():&#160;example2.c']]],
  ['var_5fname_5fd0',['VAR_NAME_D0',['../put__var_8c.html#aeb4f959fbd13b3f6a528a0303c7216ec',1,'put_var.c']]]
];
