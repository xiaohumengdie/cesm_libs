var searchData=
[
  ['scorpio_20user_20interface',['SCORPIO user interface',['../api.html',1,'']]],
  ['software_20for_20caching_20output_20and_20reads_20for_20parallel_20i_2fo_20_28scorpio_29',['Software for Caching Output and Reads for Parallel I/O (SCORPIO)',['../index.html',1,'']]],
  ['scount',['scount',['../structio__desc__t.html#a85a813c99910c2791d70718dc2984a4d',1,'io_desc_t']]],
  ['setdebuglevel',['setdebuglevel',['../group___p_i_o__setdebuglevel.html#ga197ef394cd490e1650b95ef0ab97cc85',1,'piolib_mod']]],
  ['seterrorhandlingfile',['seterrorhandlingfile',['../group___p_i_o__seterrorhandling.html#ga5c3e6c45dcd0af907b5e60c20bdae886',1,'piolib_mod']]],
  ['seterrorhandlingiosysid',['seterrorhandlingiosysid',['../group___p_i_o__seterrorhandling.html#gade8bdb3765989141d515751896e1e64e',1,'piolib_mod']]],
  ['seterrorhandlingiosystem',['seterrorhandlingiosystem',['../group___p_i_o__seterrorhandling.html#ga78b16b0612471672be4e8825dd2f2cef',1,'piolib_mod']]],
  ['setframe',['setframe',['../group___p_i_o__setframe.html#ga2c5966f917968c675e6c734c3ddbe565',1,'piolib_mod']]],
  ['sindex',['sindex',['../structio__desc__t.html#a7c861a0543de55882f06a3bf8e273622',1,'io_desc_t']]],
  ['start',['start',['../structio__region.html#a9b4bc773d62123b98bb4b0821b2f1188',1,'io_region']]],
  ['start_5fdata_5fval',['START_DATA_VAL',['../example1_8c.html#aba5ba18a0b68130c63410845f87fa708',1,'START_DATA_VAL():&#160;example1.c'],['../example2_8c.html#aba5ba18a0b68130c63410845f87fa708',1,'START_DATA_VAL():&#160;example2.c'],['../put__var_8c.html#ae6425cf092ad3bbbdb3cc8a46600f210',1,'START_DATA_VAL():&#160;put_var.c']]],
  ['stride',['stride',['../structpioexample_1_1pioexampleclass.html#a7db2a2d4a3a90efb1d15304a1302f367',1,'pioexample::pioexampleclass']]],
  ['stype',['stype',['../structio__desc__t.html#a46870b00a1e603c3c3e91cc0287c3f33',1,'io_desc_t']]],
  ['subset_5fcomm',['subset_comm',['../structio__desc__t.html#ae9e9fc0c4d6fea535c4fbe51ccd4d71f',1,'io_desc_t']]],
  ['syncfile',['syncfile',['../group___p_i_o__syncfile.html#ga2b10f2553a1dde620a57f8ac9f43c780',1,'piolib_mod']]]
];
