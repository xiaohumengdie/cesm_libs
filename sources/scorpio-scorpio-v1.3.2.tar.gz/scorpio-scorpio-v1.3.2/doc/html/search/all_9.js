var searchData=
[
  ['lgcd',['lgcd',['../pioc__sc_8c.html#a519df5fcdbcd109624e147ddc35791a9',1,'pioc_sc.c']]],
  ['lgcd_5farray',['lgcd_array',['../pioc__sc_8c.html#a9abc09db4545c9581b1b590be7d18c97',1,'pioc_sc.c']]],
  ['llen',['llen',['../structio__desc__t.html#aa774744b15b0eced2af33da10a8ed3c4',1,'io_desc_t']]],
  ['loffset',['loffset',['../structio__region.html#a65ba5fd34f21987d9c07cfb9e264b159',1,'io_region']]]
];
