var searchData=
[
  ['io_20descriptors_2c_20generating',['io descriptors, generating',['../group__iodesc__generate.html',1,'']]]
];
