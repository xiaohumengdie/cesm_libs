var searchData=
[
  ['data',['data',['../structwmulti__buffer.html#aa6079bff17b568dcb461f89faa4b09e1',1,'wmulti_buffer']]],
  ['databuffer',['databuffer',['../structpioexample_1_1pioexampleclass.html#a154ba5b20555c9ba1c8674c064f3f8fb',1,'pioexample::pioexampleclass']]],
  ['default_5ferror_5fhandler',['default_error_handler',['../pioc_8c.html#aa51ffd0af16fbe64b37ed23b3c10700a',1,'pioc.c']]],
  ['default_5frearranger',['default_rearranger',['../structiosystem__desc__t.html#a6badea08e053fb45299a22b6a57e5d46',1,'iosystem_desc_t']]],
  ['dim_5flen',['dim_len',['../example2_8c.html#a0cdd029eb53af7edd1f798d8d2425b2b',1,'example2.c']]],
  ['dim_5fname',['dim_name',['../example2_8c.html#a2ff6a13fe5da4f73ddbd691b94aaec9a',1,'example2.c']]],
  ['dimlen',['dimlen',['../structpioexample_1_1pioexampleclass.html#a04793022c40b565f88a4ae49c91b23bd',1,'pioexample::pioexampleclass::dimlen()'],['../structio__desc__t.html#a5e244740d0480f116975206d776e623b',1,'io_desc_t::dimlen()']]],
  ['do_5fio',['do_io',['../structfile__desc__t.html#a4bffd16a82bcb2734433ff50614b5b85',1,'file_desc_t']]]
];
