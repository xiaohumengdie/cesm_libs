var searchData=
[
  ['llen',['llen',['../structio__desc__t.html#aa774744b15b0eced2af33da10a8ed3c4',1,'io_desc_t']]],
  ['loffset',['loffset',['../structio__region.html#a65ba5fd34f21987d9c07cfb9e264b159',1,'io_region']]]
];
