var searchData=
[
  ['file_5fdesc_5ft',['file_desc_t',['../structpio__types_1_1file__desc__t.html',1,'pio_types::file_desc_t'],['../structfile__desc__t.html',1,'file_desc_t']]]
];
