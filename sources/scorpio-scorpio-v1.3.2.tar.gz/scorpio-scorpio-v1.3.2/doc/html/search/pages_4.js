var searchData=
[
  ['guide_20for_20contributors',['Guide for Contributors',['../contributing_code.html',1,'']]]
];
