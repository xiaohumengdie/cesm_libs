var searchData=
[
  ['scorpio_20user_20interface',['SCORPIO user interface',['../api.html',1,'']]],
  ['software_20for_20caching_20output_20and_20reads_20for_20parallel_20i_2fo_20_28scorpio_29',['Software for Caching Output and Reads for Parallel I/O (SCORPIO)',['../index.html',1,'']]]
];
