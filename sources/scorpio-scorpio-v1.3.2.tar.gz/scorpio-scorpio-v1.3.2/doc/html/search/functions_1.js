var searchData=
[
  ['calcstartandcount',['CalcStartandCount',['../pioc__sc_8c.html#a3853ca65f627c30076b4fa2a9f88b0f2',1,'pioc_sc.c']]],
  ['calculate_5fvalue',['calculate_value',['../example2_8c.html#adc94683e96f58797755afd533c093c45',1,'example2.c']]],
  ['check_5ffile',['check_file',['../example1_8c.html#a68a3f52d3825a0739cf5e076cfbebd9a',1,'check_file(int ntasks, char *filename):&#160;example1.c'],['../example2_8c.html#a68a3f52d3825a0739cf5e076cfbebd9a',1,'check_file(int ntasks, char *filename):&#160;example2.c']]],
  ['checkmpireturn',['checkmpireturn',['../pio__support_8_f90.html#ac7968ba27902096f4dd743d468f25274',1,'pio_support']]],
  ['cleanup',['cleanup',['../structpioexample_1_1pioexampleclass.html#a98dc8381c73aa16077022c2601af502a',1,'pioexample::pioexampleclass']]],
  ['closefile',['closefile',['../structpioexample_1_1pioexampleclass.html#ad8d27e01569f9dfd28876febc5d42638',1,'pioexample::pioexampleclass::closefile()'],['../group___p_i_o__closefile.html#gabd36983797d48236a8d610b58a7c3aa8',1,'piolib_mod::closefile()']]],
  ['compute_5fone_5fdim',['compute_one_dim',['../pioc__sc_8c.html#aea4b479a6d54a088387e3948d967b232',1,'pioc_sc.c']]],
  ['createdecomp',['createdecomp',['../structpioexample_1_1pioexampleclass.html#a6a47fedad0fe0d131fd0305e25b26546',1,'pioexample::pioexampleclass']]],
  ['createfile',['createfile',['../structpioexample_1_1pioexampleclass.html#ac1010cbbdf5cd79112bab8e3dbd5dfdf',1,'pioexample::pioexampleclass::createfile()'],['../group___p_i_o__createfile.html#ga359c93e9d4f79c37d488f00535122177',1,'piolib_mod::createfile()']]]
];
