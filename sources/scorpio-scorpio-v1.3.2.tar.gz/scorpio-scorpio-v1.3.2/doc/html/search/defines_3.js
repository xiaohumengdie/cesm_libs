var searchData=
[
  ['ndim',['NDIM',['../example1_8c.html#a2b1fd2d28c6a7d4a3f7027cc1b6466f3',1,'NDIM():&#160;example1.c'],['../example2_8c.html#a2b1fd2d28c6a7d4a3f7027cc1b6466f3',1,'NDIM():&#160;example2.c'],['../put__var_8c.html#a2b1fd2d28c6a7d4a3f7027cc1b6466f3',1,'NDIM():&#160;put_var.c']]],
  ['num_5fevents',['NUM_EVENTS',['../example2_8c.html#ae769ca99bba831a6bfbf2e98d60aa1fb',1,'example2.c']]],
  ['num_5fnetcdf_5fflavors',['NUM_NETCDF_FLAVORS',['../example1_8c.html#ae763c3ffeab20d06c1ab807cabb82394',1,'NUM_NETCDF_FLAVORS():&#160;example1.c'],['../example2_8c.html#ae763c3ffeab20d06c1ab807cabb82394',1,'NUM_NETCDF_FLAVORS():&#160;example2.c'],['../put__var_8c.html#ae763c3ffeab20d06c1ab807cabb82394',1,'NUM_NETCDF_FLAVORS():&#160;put_var.c']]],
  ['num_5ftimesteps',['NUM_TIMESTEPS',['../example2_8c.html#a78076335bc3d03745246fc5ffcdd4e85',1,'example2.c']]]
];
