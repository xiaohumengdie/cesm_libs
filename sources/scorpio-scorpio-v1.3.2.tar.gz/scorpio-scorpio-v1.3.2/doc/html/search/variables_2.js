var searchData=
[
  ['chunksize',['chunksize',['../example2_8c.html#ac370740bf1adc58a8c18773ffd823ebf',1,'example2.c']]],
  ['comm_5ftype',['comm_type',['../structrearr__opt.html#a342fe712d7506465b38916591820ae7e',1,'rearr_opt']]],
  ['comp2io',['comp2io',['../structrearr__opt.html#aeca20bb690f07a0caa04c5f1ae95a256',1,'rearr_opt']]],
  ['comp_5fcomm',['comp_comm',['../structiosystem__desc__t.html#a362435c96f238f4c90da56af73454199',1,'iosystem_desc_t']]],
  ['comp_5fidx',['comp_idx',['../structiosystem__desc__t.html#a57a0b192ffe2f569d21ae31fc998ef88',1,'iosystem_desc_t']]],
  ['comp_5frank',['comp_rank',['../structiosystem__desc__t.html#a77a14897f1dc8aede4ec7f42b2566327',1,'iosystem_desc_t']]],
  ['compdof',['compdof',['../structpioexample_1_1pioexampleclass.html#a543d2bef96e9ef2817838921a3e17fd8',1,'pioexample::pioexampleclass']]],
  ['compgroup',['compgroup',['../structiosystem__desc__t.html#a6ccc5dc3e7a8fe725b7738c3298d2c7e',1,'iosystem_desc_t']]],
  ['compmaster',['compmaster',['../structiosystem__desc__t.html#ae338cd1c51fc385932faefe5c80377a7',1,'iosystem_desc_t']]],
  ['compproc',['compproc',['../structiosystem__desc__t.html#a5076e66faed9677a6ed686348fff1033',1,'iosystem_desc_t']]],
  ['compranks',['compranks',['../structiosystem__desc__t.html#ae9147c3aba3e40bf2d3ad06ba2305512',1,'iosystem_desc_t']]],
  ['comproot',['comproot',['../structiosystem__desc__t.html#aeb4289bb6f3ea243e1a9bae70b45aaf9',1,'iosystem_desc_t']]],
  ['count',['count',['../structio__region.html#ae9897b9dc1ae1abb8e6421d55a8e4b20',1,'io_region']]]
];
