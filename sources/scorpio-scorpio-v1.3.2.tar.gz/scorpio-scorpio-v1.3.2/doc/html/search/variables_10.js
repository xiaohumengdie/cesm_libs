var searchData=
[
  ['varlist',['varlist',['../structfile__desc__t.html#acee23027c33ce296ec6f48694716ba95',1,'file_desc_t']]],
  ['vid',['vid',['../structwmulti__buffer.html#aee096a9cf8b6affe737fb39cb4cddfdc',1,'wmulti_buffer']]]
];
