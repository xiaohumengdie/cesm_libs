var searchData=
[
  ['var_5fdesc_5ft',['var_desc_t',['../structvar__desc__t.html',1,'var_desc_t'],['../structpio__types_1_1var__desc__t.html',1,'pio_types::var_desc_t'],['../pio_8h.html#acb64b706f665bab44861cb168a985dd2',1,'var_desc_t():&#160;pio.h']]],
  ['var_5fname',['VAR_NAME',['../example1_8c.html#a73de0b1772c59096554d6a846feff376',1,'VAR_NAME():&#160;example1.c'],['../example2_8c.html#a73de0b1772c59096554d6a846feff376',1,'VAR_NAME():&#160;example2.c']]],
  ['var_5fname_5fd0',['VAR_NAME_D0',['../put__var_8c.html#aeb4f959fbd13b3f6a528a0303c7216ec',1,'put_var.c']]],
  ['varlist',['varlist',['../structfile__desc__t.html#acee23027c33ce296ec6f48694716ba95',1,'file_desc_t']]],
  ['vid',['vid',['../structwmulti__buffer.html#aee096a9cf8b6affe737fb39cb4cddfdc',1,'wmulti_buffer']]]
];
