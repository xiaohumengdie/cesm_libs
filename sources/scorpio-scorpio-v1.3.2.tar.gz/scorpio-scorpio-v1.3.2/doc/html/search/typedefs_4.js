var searchData=
[
  ['var_5fdesc_5ft',['var_desc_t',['../pio_8h.html#acb64b706f665bab44861cb168a985dd2',1,'pio.h']]]
];
