var searchData=
[
  ['scount',['scount',['../structio__desc__t.html#a85a813c99910c2791d70718dc2984a4d',1,'io_desc_t']]],
  ['sindex',['sindex',['../structio__desc__t.html#a7c861a0543de55882f06a3bf8e273622',1,'io_desc_t']]],
  ['start',['start',['../structio__region.html#a9b4bc773d62123b98bb4b0821b2f1188',1,'io_region']]],
  ['start_5fdata_5fval',['START_DATA_VAL',['../put__var_8c.html#ae6425cf092ad3bbbdb3cc8a46600f210',1,'put_var.c']]],
  ['stride',['stride',['../structpioexample_1_1pioexampleclass.html#a7db2a2d4a3a90efb1d15304a1302f367',1,'pioexample::pioexampleclass']]],
  ['stype',['stype',['../structio__desc__t.html#a46870b00a1e603c3c3e91cc0287c3f33',1,'io_desc_t']]],
  ['subset_5fcomm',['subset_comm',['../structio__desc__t.html#ae9e9fc0c4d6fea535c4fbe51ccd4d71f',1,'io_desc_t']]]
];
