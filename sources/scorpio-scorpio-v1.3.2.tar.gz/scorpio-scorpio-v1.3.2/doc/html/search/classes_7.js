var searchData=
[
  ['wmulti_5fbuffer',['wmulti_buffer',['../structwmulti__buffer.html',1,'']]]
];
