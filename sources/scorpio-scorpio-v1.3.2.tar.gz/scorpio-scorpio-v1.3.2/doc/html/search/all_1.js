var searchData=
[
  ['blocksize',['blocksize',['../pioc_8c.html#a75e9073defcedf91712de41e4ac14800',1,'blocksize():&#160;pioc_sc.c'],['../pioc__sc_8c.html#a75e9073defcedf91712de41e4ac14800',1,'blocksize():&#160;pioc_sc.c']]],
  ['buffer',['buffer',['../structfile__desc__t.html#a9509da72bd6b683459f67d860414883a',1,'file_desc_t']]]
];
